# Changelog

## 0.1.2 - 2026-02-02
- Automated release bundle generated for CI Guardrails - Branch Policy.

## 0.1.1 - 2026-02-02
- Automated release bundle generated for CI Guardrails - Branch Policy.
